package com.app.PositionSensorActivity;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class PositionSensorService extends Service{

	@Override
	public IBinder onBind(Intent arg0) {
		// TODO Auto-generated method stub
		return null;
	}

}
